# Task 01

When the user clicks the included button, you should change the text color, font family, and font size of the included paragraph using JavaScript.

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.
