# Task 01

Wenn der Benutzer auf den enthaltenen Button klickt, sollst du die Textfarbe, die Schriftart und die Schriftgröße des enthaltenen Paragraphen mit JavaScript ändern.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.
