# Single Page Application - Exam 1

This exam has 9 separate tasks. You have 90 minutes to complete all of the tasks. If you run out of time, commit and push your work, even if it is incomplete!

The tasks are in separate folders with instructions in a README.md file.

**Rules**

- You are not allowed to receive help from classmates or teachers to complete the tasks. However, you are allowed to ask the teacher or assistant teacher to clarify a task (within reason)
- You are free to use Google, but AIs like ChatGPT/OpenAI are not allowed.
- The copying of Answers (from Students,  AI, etc) will result in an automatic fail for the student.

Good Luck; Have Fun!
