# Single Page Application - Exam 1

Diese Prüfung besteht aus 9 einzelnen Aufgaben. Du hast 90 Minuten Zeit, um alle Aufgaben zu lösen. Wenn dir die Zeit davonläuft, commit und push deine Arbeit, auch wenn sie unvollständig ist!

Die Aufgaben befinden sich in separaten Ordnern mit Anweisungen in einer README.md-Datei (auf Deutsch in README_DE.md).

**Regeln**

 - Die Studenten durfen keine Hilfe von Kollegen oder Lehrer bekommen, um eine Aufgaben zu erledigen. Jedoch, können die Studenten eine Frage (in angemessenem Rahmen) mit einem Lehrer oder Assistent Lehrer klären.
 - Studenten dürfen Google nutzen, aber nicht AIs wie ChatGPT/OpenAI. 
 - Das Kopieren von Antworten (von Studenten, AI, usw) führt zu einem automatischen Nichtbestehen des/der Student/in.

Viel Glück und viel Spaß!
