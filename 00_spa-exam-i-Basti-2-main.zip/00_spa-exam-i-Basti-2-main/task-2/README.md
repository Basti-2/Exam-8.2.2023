# Task 02

Write a JavaScript function to `console.log()` the values of the href, hreflang, rel, target, and type attributes of the first link in the page. That function should run when the button is clicked.

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.
