# Task 02

Schreibe eine JavaScript-Funktion, um die Werte der Attribute href, hreflang, rel, target und type des ersten Links auf der Seite auf `console.log()` auszugeben. Diese Funktion soll ausgeführt werden, wenn der Button angeklickt wird.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.