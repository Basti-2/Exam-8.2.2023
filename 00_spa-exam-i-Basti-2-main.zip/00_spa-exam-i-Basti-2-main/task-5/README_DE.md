# Task 05

Mit JavaScript, wenn der Button auf der Seite angeklickt wird, sollst du die Summe jeder Zeile berechnen und den berechneten Wert als Zelle in dieselbe Zeile einfügen.

Nachdem du 2 Mal auf den Button geklickt hast, soll deine Tabelle wie folgt aussehen:

```
  | 1 | 1 | 2 | 4 |
  | 1 | 2 | 3 | 6 |
```

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.