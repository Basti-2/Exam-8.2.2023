# Task 05

Using JavaScript, when the button on the page is clicked you need to calculate the sum of each row and  add the calculated value as a cell into the same row.

After the clicking the button 2 times, your table should look like this:

```
  | 1 | 1 | 2 | 4 |
  | 1 | 2 | 3 | 6 |
```

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.

