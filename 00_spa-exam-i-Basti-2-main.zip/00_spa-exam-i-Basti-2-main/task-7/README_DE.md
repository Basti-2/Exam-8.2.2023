# Task 07

Verwende JavaScript, um das Volumen einer Kugel auf der Grundlage von Werten, die der Benutzer in das vorgegebene Formular eingegeben hat, zu berechnen und mit `alert()` auszugeben. Die Berechnung und `alert` müssen immer dann erfolgen, wenn das beigefügte Formular abgeschickt (submitted) wird.

Verwende die Formel "V = 4/3πr", wobei "r" der Radius ist, um das Volumen zu berechnen.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.