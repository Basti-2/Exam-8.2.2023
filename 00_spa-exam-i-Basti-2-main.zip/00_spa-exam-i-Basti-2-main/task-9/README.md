# Task 09

Using JavaScripts native prompt function, ask the user 'What's your name?' when the page loads.

If the user doesn't insert a name, prompt them again.

If the user has inserted a name, display a greeting to the user with their name.

Example: "Hello Steve", "Hello Mary"

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.
