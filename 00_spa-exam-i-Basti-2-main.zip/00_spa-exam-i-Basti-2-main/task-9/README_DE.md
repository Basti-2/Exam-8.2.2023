# Task 09

Benutze JavaScript und zeige die Breite und Höhe des Browserfensters auf der Seite an, wobei die Zahlen beim Laden der Seite und bei jeder Größenänderung des Fensters aktualisiert werden sollen.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.