# Task 08

Verwende JavaScript und lasse das Wort "gobbledygook" nur dann fett (bold) und rot erscheinen, wenn der Benutzer mit der Maus über den Paragraphen fährt, der dieses Wort enthält.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.