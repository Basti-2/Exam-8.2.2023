# Task 08

Use JavaScript to make the word "gobbledygook" appear bold and red only when the user has their mouse over the paragraph containing that word.

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.
