# Taks 04

Verwende JavaScript, um die Werte der Eingaben "First name" und "Last name" auf `console.log()` auszugeben, wenn das Formular abgeschickt (submitted) wird.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.