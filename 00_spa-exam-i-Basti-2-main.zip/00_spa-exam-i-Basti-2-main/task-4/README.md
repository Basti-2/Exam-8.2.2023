# Task 04

Use JavaScript to `console.log()` the values of the First and Last name inputs when the form is submitted.

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.
