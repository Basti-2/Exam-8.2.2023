# Task 03

Verwende JavaScript, um die Aufgabe zu lösen, nicht CSS. Wenn ein Benutzer ein Eingabefeld fokussiert, um darin zu schreiben, gib diesem Eingabefeld einen roten Rahmen (5px Border). Wenn das Eingabefeld den Fokus verliert, entferne die rote Rahmenfarbe.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.