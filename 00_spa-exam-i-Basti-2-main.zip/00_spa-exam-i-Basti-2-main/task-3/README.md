# Task 03

Use JavaScript to complete the task, not CSS. When a user focuses an input field to write into it, give that input field a red border of 5px. When that input field loses the focus, remove the red border color.

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.
