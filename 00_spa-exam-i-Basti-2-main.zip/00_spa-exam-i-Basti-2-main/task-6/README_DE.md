# Task 06

Schreibe ein JavaScript-Programm, um das aktuell ausgewählte Element aus der Dropdown-Liste zu entfernen, wenn der enthaltene Button angeklickt wird.

Bearbeite den HTML-Code nicht, außer um JavaScript hinzuzufügen.
Halte das JavaScript inline.