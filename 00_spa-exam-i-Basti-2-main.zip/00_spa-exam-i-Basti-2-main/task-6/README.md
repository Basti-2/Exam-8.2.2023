# Task 06

Write a JavaScript program to remove the currently selected item from the dropdown list when the included button is clicked.

Don't edit the HTML other than adding JavaScript.
Keep the JavaScript inline.